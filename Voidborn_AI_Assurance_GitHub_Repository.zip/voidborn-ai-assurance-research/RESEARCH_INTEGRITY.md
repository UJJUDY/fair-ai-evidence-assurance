# Research integrity and scope

- All banking records, errors, risk rates, agents and outcomes in the experiments are simulated.
- No conclusions about Citi internal controls, AI performance, customer outcomes or compliance are supported by these experiments.
- The synthetic results are conditional on the stated simulation assumptions and comparator choices.
- Reproducing a known statistical phenomenon is not evidence of a novel discovery.
- Experiment 04 contains an important negative result for the proposed trace-informed audit approach.
- FAIR-AI and the Evidence Readiness Gate remain research concepts and require external validation.
- Review the experiment reports for assumptions, limitations and interpretation.
