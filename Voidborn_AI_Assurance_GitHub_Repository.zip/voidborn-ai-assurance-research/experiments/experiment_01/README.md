# Voidborn Tech — Beyond AI Approval
Independent public-information case study; research baseline 15 October 2026.

## Research question
How can a bank produce independently testable, continuous assurance evidence for AI agents performing multi-step workflows?

## Verified primary sources
1. Citi, Introducing AI Agents, 30 April 2026: https://www.citigroup.com/global/news/perspectives/2026/introducing-ai-agents-next-phase-citi-artificial-intelligence-journey
2. PRA SS1/23 current version, April 2026: https://www.bankofengland.co.uk/prudential-regulation/publication/2023/may/model-risk-management-principles-for-banks-ss
3. ICO, Data (Use and Access) Act 2025 data protection changes: https://ico.org.uk/about-the-ico/what-we-do/legislation-we-cover/data-use-and-access-act-2025/the-data-use-and-access-act-2025-duaa-summary-of-the-changes/data-protection/
4. ICO, AI and data protection guidance: https://ico.org.uk/for-organisations/uk-gdpr-guidance-and-resources/artificial-intelligence/

## Scope
Synthetic KYC/onboarding workflow; illustrative only. No Citi internal data, no claim of actual Citi control failure, no legal compliance certification.

## Hypotheses to test
H1: Event-level evidence enables reconstruction of simulated agent decisions.
H2: Permission checks block predefined unauthorised tool calls.
H3: Evidence-verification checks flag unsupported recommendations.
H4: Meaningful-review checks detect simulated rubber-stamp approvals.
H5: Data-quality checks detect missing or inconsistent fields.

## Evaluation protocol
For each control define test cases, expected outcome, observed outcome, false positives, false negatives, and limitations. Preserve reproducible test fixtures and event logs.

## Research stages
1. Citi disclosure and regulatory applicability matrix.
2. Synthetic workflow specification and threat model.
3. Deterministic simulator and test harness.
4. Audit-evidence dataset and Power BI dashboard.
5. Research paper, limitations, executive brief, CV and outreach alignment.
