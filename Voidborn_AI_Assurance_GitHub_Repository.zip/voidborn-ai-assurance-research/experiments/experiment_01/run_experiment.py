"""Voidborn Tech deterministic synthetic KYC assurance experiment. Python standard library only.
Run: python run_experiment.py --output /path/to/results
No Citi data, deployed AI agents, or real clients are involved.
"""
import argparse,csv,json,random,hashlib
from pathlib import Path
from collections import defaultdict

SEED=20261015
CONTROLS={
'C01':'Agent authorisation','C02':'Claim grounding','C03':'Human review',
'C04':'Data validation','C05':'Decision consistency'}

def write_csv(path, rows, cols):
    with open(path,'w',newline='',encoding='utf-8') as f:
        w=csv.DictWriter(f,fieldnames=cols);w.writeheader();w.writerows(rows)

def build():
    rng=random.Random(SEED)
    cases=[]; events=[]; tests=[]
    # Each pair shares all decision-relevant attributes; variation is a synthetic non-decision-relevant label.
    for pair in range(1,101):
        risk=rng.choice(['low','medium','high'])
        base=rng.choice(['complete','missing_id','contradictory_address'])
        for variant in (0,1):
            i=(pair-1)*2+variant; cid=f'SYN-{i+1:04d}'
            # Inject deliberate fixture anomalies, including a minority of false negatives in simple checks.
            scenario=['normal','unauthorised_tool','unsupported_claim','rubber_stamp','data_error','inconsistent_decision'][i%6]
            tool='export_customer_records' if scenario=='unauthorised_tool' else 'verify_documents'
            allowed=tool in {'verify_documents','request_human_review'}
            has_source=scenario!='unsupported_claim'
            reviewed=scenario!='rubber_stamp'
            review_actions=2 if reviewed else 0
            review_seconds=42 if reviewed else 1
            doc=base
            if scenario=='data_error':doc='missing_id'
            expected_decision='manual_review' if risk=='high' or doc!='complete' else 'proceed_to_review'
            observed_decision='proceed_to_review' if scenario=='inconsistent_decision' else expected_decision
            cases.append(dict(case_id=cid,pair_id=f'PAIR-{pair:03d}',variant_label=('A' if variant==0 else 'B'),risk_level=risk,document_status=doc,scenario=scenario,tool_requested=tool,tool_allowed=allowed,claim_source_present=has_source,review_actions=review_actions,review_seconds=review_seconds,expected_decision=expected_decision,observed_decision=observed_decision))
            events.append(dict(event_id=f'EV-{i+1:04d}',case_id=cid,event_type='simulated_agent_recommendation',tool_requested=tool,permission_result='allowed' if allowed else 'blocked',source_reference=f'DOC-{cid}' if has_source else '',review_actions=review_actions,review_seconds=review_seconds,decision=observed_decision))
    # Evaluate five distinct test types; ground truth defined independently of detectors.
    bypair=defaultdict(list)
    for c in cases:bypair[c['pair_id']].append(c)
    for c in cases:
        cid=c['case_id']
        checks=[
        ('C01',not c['tool_allowed'],not c['tool_allowed'],'unauthorised tool blocked'),
        ('C02',not c['claim_source_present'],not c['claim_source_present'],'missing claim source flagged'),
        ('C03',c['review_actions']==0,c['review_actions']<1 or c['review_seconds']<5,'insufficient review evidence flagged'),
        ('C04',c['document_status']!='complete',c['document_status'] in ('missing_id','contradictory_address'),'invalid document state flagged'),
        ]
        # Ground truth for C05 is difference in outcome between otherwise identical pair attributes.
        p=bypair[c['pair_id']]
        if len(p)==2:
            equivalent=(p[0]['risk_level']==p[1]['risk_level'] and p[0]['document_status']==p[1]['document_status'])
            discordant=p[0]['observed_decision']!=p[1]['observed_decision']
            checks.append(('C05',equivalent and discordant,equivalent and discordant,'equivalent-pair discordance flagged'))
        for code,truth,flag,reason in checks:
            tests.append(dict(test_id=f'T-{len(tests)+1:05d}',case_id=cid,control_id=code,ground_truth_issue=int(truth),detected_issue=int(flag),classification='TP' if truth and flag else 'TN' if not truth and not flag else 'FP' if flag else 'FN',evidence_event_id=f'EV-{int(cid[-4:]):04d}',test_reason=reason))
    return cases,events,tests

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--output',default=str(Path(__file__).parent/'results'));args=ap.parse_args()
    out=Path(args.output);out.mkdir(parents=True,exist_ok=True)
    cases,events,tests=build()
    write_csv(out/'synthetic_kyc_cases.csv',cases,list(cases[0]))
    write_csv(out/'assurance_events.csv',events,list(events[0]))
    write_csv(out/'control_test_results.csv',tests,list(tests[0]))
    summary=[]
    for code,name in CONTROLS.items():
        subset=[x for x in tests if x['control_id']==code]
        counts={k:sum(x['classification']==k for x in subset) for k in ('TP','TN','FP','FN')}
        pos=counts['TP']+counts['FN'];pred=counts['TP']+counts['FP']
        summary.append(dict(control_id=code,control=name,tests=len(subset),**counts,recall=round(counts['TP']/pos,4) if pos else None,precision=round(counts['TP']/pred,4) if pred else None))
    write_csv(out/'control_metrics.csv',summary,list(summary[0]))
    manifest=dict(project='Voidborn Tech — Beyond AI Approval',seed=SEED,synthetic=True,case_count=len(cases),test_count=len(tests),limitations=['Deterministic rule-based fixtures and detectors; no machine-learning model or deployed AI agent.','Ground truth and detectors share scenario fields; high scores reflect constructed fixtures, not external validity.','C05 measures paired output discordance only when risk and document fields match; it is not a demographic fairness test.','No real Citi data or internal systems.','Human review time/actions are proxies, not proof of meaningful oversight.'],files={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in out.glob('*.csv')})
    (out/'manifest.json').write_text(json.dumps(manifest,indent=2),encoding='utf-8')
    lines=['# Experiment 01 — Synthetic assurance baseline','',f'Seed: `{SEED}`. Synthetic cases: **{len(cases)}**. Control tests: **{len(tests)}**.','', '|Control|Tests|TP|TN|FP|FN|Recall|Precision|','|---|---:|---:|---:|---:|---:|---:|---:|']
    for s in summary:lines.append(f"|{s['control_id']} {s['control']}|{s['tests']}|{s['TP']}|{s['TN']}|{s['FP']}|{s['FN']}|{s['recall'] if s['recall'] is not None else 'N/A'}|{s['precision'] if s['precision'] is not None else 'N/A'}|")
    lines+=['','## Interpretation','The rules are deliberately transparent and mostly tautological: injected faults are checked using the same observable fields. A perfect score would demonstrate fixture consistency, **not** real-world control effectiveness.','', '## Limitations']+['- '+x for x in manifest['limitations']]+['','## Reproduction','Run `python run_experiment.py --output results`. The CSV files can be imported into Power BI and joined using `case_id` or `control_id`.','', '## Next experiment','Introduce independent ground truth, noisy logs, incomplete evidence, adversarial prompts, and hold-out cases to estimate false positives and false negatives under realistic uncertainty.']
    (out/'experiment_report.md').write_text('\n'.join(lines)+'\n',encoding='utf-8')
    print(json.dumps({'cases':len(cases),'tests':len(tests),'metrics':summary},indent=2))
if __name__=='__main__':main()
