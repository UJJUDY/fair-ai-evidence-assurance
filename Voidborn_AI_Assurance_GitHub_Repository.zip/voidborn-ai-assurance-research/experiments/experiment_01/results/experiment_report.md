# Experiment 01 — Synthetic assurance baseline

Seed: `20261015`. Synthetic cases: **200**. Control tests: **1000**.

|Control|Tests|TP|TN|FP|FN|Recall|Precision|
|---|---:|---:|---:|---:|---:|---:|---:|
|C01 Agent authorisation|200|34|166|0|0|1.0|1.0|
|C02 Claim grounding|200|33|167|0|0|1.0|1.0|
|C03 Human review|200|33|167|0|0|1.0|1.0|
|C04 Data validation|200|142|58|0|0|1.0|1.0|
|C05 Decision consistency|200|20|180|0|0|1.0|1.0|

## Interpretation
The rules are deliberately transparent and mostly tautological: injected faults are checked using the same observable fields. A perfect score would demonstrate fixture consistency, **not** real-world control effectiveness.

## Limitations
- Deterministic rule-based fixtures and detectors; no machine-learning model or deployed AI agent.
- Ground truth and detectors share scenario fields; high scores reflect constructed fixtures, not external validity.
- C05 measures paired output discordance only when risk and document fields match; it is not a demographic fairness test.
- No real Citi data or internal systems.
- Human review time/actions are proxies, not proof of meaningful oversight.

## Reproduction
Run `python run_experiment.py --output results`. The CSV files can be imported into Power BI and joined using `case_id` or `control_id`.

## Next experiment
Introduce independent ground truth, noisy logs, incomplete evidence, adversarial prompts, and hold-out cases to estimate false positives and false negatives under realistic uncertainty.
