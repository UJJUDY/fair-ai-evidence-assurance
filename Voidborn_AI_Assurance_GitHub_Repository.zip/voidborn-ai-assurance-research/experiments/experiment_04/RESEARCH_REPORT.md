# Voidborn Tech | Experiment 04: The AI Measurement Blind Spot

Date: 15 October 2026. Independent synthetic research. Not sponsored by or based on Citi internal data.

## Research question
Can selective observation across a simulated multi-agent workflow cause the observed error rate to improve while the true error rate worsens? Can established audit estimators recover the true rate?

## Design
30 fixed seeds per period, 20,000 cases per seed; 1.2 million synthetic case-period records in total. Each case has observed risk `x`, latent risk `u`, and a binary adverse outcome `y`. In the later period, the probability of `y` rises and the probability that `y` is reviewed increasingly favours low-risk cases. Three agents are conceptual workflow stages; this is **not** a deployed multi-agent LLM environment. Outcomes are observed for 97% of selected reviews. Simulated independent audits can access ground truth, an optimistic assumption. Audit budget: 400 per run (2% of cases).

## Findings
Earlier: mean true 7.02%, reviewed-only 6.80%. Later: true 14.36%, reviewed-only 6.19%. The reported metric improves by 0.61 percentage points while actual risk increases 7.34 points.

Later-period mean absolute error: reviewed-only 8.17 percentage points; observable-feature inverse propensity weighting 7.29 points; random audit 1.58 points; x-stratified audit 1.43 points; trace-stratified audit 1.59 points. In this setup the proposed trace-informed approach does **not** outperform the standard stratified audit. This is a negative result for any claimed superiority.

## What is and is not established
Demonstrates a constructed counterexample and reproduces estimator comparisons. Does not validate an original method, identify a Citi vulnerability, establish financial impact, prove actual agent behaviour, or generalise to real-world systems. IPW is misspecified because review propensity depends on unobserved `u`. The proposed trace feature is an artificial noisy proxy for `u`; its availability in real systems is unproven. Audit ground truth is instant and costless beyond sample budget; real KYC outcomes can be delayed, contested or unobservable. Period scenarios differ by design, not causally estimated deployment effects. No confidence intervals or significance tests are asserted. No customer protected characteristics are simulated.

## Next tests
Vary audit budget and hidden-risk strength; add delayed/ambiguous outcomes and label errors; test positivity violations; compare doubly robust and adaptive designs; simulate shared-agent dependencies explicitly; preregister hypotheses and evaluate on unseen generators. Explore operational feasibility and audit cost.

## Reproduction
`python experiment.py` writes `replicate_results.csv` and `summary.csv`. Requires numpy and pandas. Deterministic fixed seeds.
