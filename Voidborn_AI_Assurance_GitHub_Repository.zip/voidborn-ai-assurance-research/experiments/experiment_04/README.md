# Experiment 04 research package

- `experiment.py`: complete reproducible synthetic experiment
- `replicate_results.csv`: run-level observations
- `summary.csv`: comparison of estimators, error and bias
- `RESEARCH_REPORT.md`: methodology, findings and limitations

Not Citi data, not a validated FAIR-AI product. See report before citing figures.
