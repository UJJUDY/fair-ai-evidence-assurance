
import numpy as np, pandas as pd
from pathlib import Path
ROOT=Path(__file__).resolve().parent
N=20000; SEEDS=range(30); BUDGET=400
def sigmoid(x): return 1/(1+np.exp(-np.clip(x,-30,30)))
def run(seed,scenario):
    rng=np.random.default_rng(seed+1234)
    x=rng.normal(size=N)  # observed case risk
    u=rng.normal(size=N)  # unobserved risk shared across agents
    # Agent A routes, B suppresses escalation, C creates summary
    p_true=sigmoid(-3.05 + .65*x + .85*u + (0.0 if scenario=="early" else .9))
    y=(rng.random(N)<p_true).astype(int)
    # Later period improves *reported* metrics by selecting lower risk for review
    selection=sigmoid(-.25 + (.1 if scenario=="early" else -2.0)*x +
                      (-.15 if scenario=="early" else -2.7)*u)
    reviewed=rng.random(N)<selection
    observed=reviewed & (rng.random(N)<.97) # delayed/missing observed outcomes
    true=y.mean()
    dashboard=y[observed].mean()
    # Methods: uniform random independent audit, stratified allocation,
    # IPW using *observed* x only (misspecified due to latent u).
    idx=rng.choice(N,size=BUDGET,replace=False)
    simple=y[idx].mean()
    strata=np.digitize(x,[-.7,0,.7])
    allocation=[100]*4
    strat=0
    for k,n in enumerate(allocation):
        pool=np.where(strata==k)[0]
        chosen=rng.choice(pool,size=n,replace=False)
        strat+=(len(pool)/N)*y[chosen].mean()
    # Naive observable propensity correction: bin x, ignores u and missingness.
    binid=np.digitize(x,np.quantile(x,np.linspace(0,1,11)[1:-1]))
    p=np.array([max(.02,observed[binid==k].mean()) for k in range(10)])
    weights=observed/p[binid]
    ipw=(weights*y).sum()/weights.sum()
    # Proposed cross-agent audit prioritisation based on observable trace disagreement:
    # proxy correlated with hidden u, but not access to true y or u.
    trace=u + rng.normal(scale=1.5,size=N)  # SIMULATED TRACE, strong modeling assumption
    score=.65*x+.55*trace
    # 50% budget on high score, 50% random, use known inclusion probabilities
    # instead use partition strata with known population weights to avoid selection bias
    high=score>=np.quantile(score,.8)
    hi=rng.choice(np.where(high)[0],size=200,replace=False)
    lo=rng.choice(np.where(~high)[0],size=200,replace=False)
    proposed=high.mean()*y[hi].mean()+(~high).mean()*y[lo].mean()
    return dict(seed=seed,scenario=scenario,true=true,reviewed_only=dashboard,
                random_audit=simple,stratified_audit=strat,observed_ipw=ipw,
                trace_stratified_audit=proposed,review_fraction=observed.mean())
rows=[run(seed,sc) for seed in SEEDS for sc in ("early","later")]
df=pd.DataFrame(rows)
df.to_csv(ROOT/"replicate_results.csv",index=False)
metrics=[]
for sc,g in df.groupby("scenario"):
    for method in ["reviewed_only","random_audit","stratified_audit","observed_ipw","trace_stratified_audit"]:
        err=g[method]-g["true"]
        metrics.append(dict(scenario=sc,method=method,mean_true_rate=g["true"].mean(),
           mean_estimated_rate=g[method].mean(),bias=err.mean(),
           mae=err.abs().mean(),rmse=np.sqrt(np.mean(err**2)),
           mean_review_fraction=g.review_fraction.mean(),runs=len(g)))
pd.DataFrame(metrics).to_csv(ROOT/"summary.csv",index=False)
print(pd.DataFrame(metrics).to_string(index=False,float_format=lambda x:f"{x:.4f}"))
