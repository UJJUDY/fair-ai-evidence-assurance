# Voidborn Tech — Experiment 03: The AI Measurement Blind Spot
**Independent synthetic research | 15 October 2026**

## Executive summary
A bank's reviewed-case error rate may be an unrepresentative measure of its population-wide error rate when the review process selects cases non-randomly. In this synthetic experiment, the reviewed-only estimate understated true failure rates by 2.47–6.44 percentage points across three designed scenarios. The experiment demonstrates a known selective-labels problem, **not a newly discovered phenomenon, an evaluation of Citi, or a validated FAIR-AI product**.

## Design
- 100,000 simulated decisions per scenario and seed; 3 scenarios × 10 seeds = **3 million simulated decisions** (not 3 million unique bank customers).
- Four observed risk strata with population shares 40%, 30%, 20%, 10%.
- Baseline true error probabilities: 1.5%, 4%, 9.5%, 18%; error probabilities increase under moderate and severe deterioration.
- Reviewed-case inclusion probabilities are risk-stratum-dependent and change by scenario; review disproportionately selects low-risk cases.
- Comparator A: reviewed-only mean, which ignores missing labels.
- Comparator B: simple random independent audit, 2,000 cases per run.
- Comparator C: inverse-propensity weighting (IPW), using **known exact review probabilities**, an unrealistically strong assumption.
- Comparator D: stratified independent audit, 500 cases per stratum, weighted back to population composition.
- True outcomes are visible only to the simulation's evaluation oracle, not to the reviewed-only method.

## Results (means across 10 seeds; see summary.csv for full metrics)
| Scenario | True failure rate | Reviewed-only estimate | Random audit estimate | IPW estimate | Stratified audit estimate |
|---|---:|---:|---:|---:|---:|
| Baseline | 5.50% | 3.03% | 5.54% | 5.49% | 5.85% |
| Moderate deterioration | 8.17% | 3.71% | 8.25% | 8.14% | 8.68% |
| Severe deterioration | 10.86% | 4.42% | 10.94% | 10.92% | 11.25% |

**Interpretation:** The reviewed-only dashboard misses a growing share of underlying errors. In this specific experiment its displayed error rate still worsens, so we have **not** demonstrated improving dashboard performance alongside worsening reality. Stratified audit has a small positive realised error in these ten seeds; it is not theoretically biased under this sampling design. IPW becomes noisy under rare high-risk reviews (mean absolute error 1.13 percentage points in the severe scenario). The sample is too small to establish robust rankings among estimators.

## Implications for a Citi-facing case study
This is a *hypothetical* bank-wide assurance challenge relevant to selective investigations, KYC triage, fraud detection and agentic workflows. Nothing in these synthetic results establishes Citi's own review-selection mechanisms, risk levels, model performance, or governance shortcomings.

A credible extension would instrument agent decisions and review selection, estimate review propensities rather than assuming them known, add unobserved confounding, delayed outcomes and shared dependencies, and evaluate independent audit allocation under equal cost budgets. A proposed FAIR-AI contribution would need to outperform or complement established selective-label correction and auditing methods on held-out scenarios.

## Limits and research integrity
1. All outcomes and review-selection rules are authored by the simulator; they are not representative of real banks.
2. The four risk groups are fully observable; real review decisions may depend on hidden variables.
3. IPW is given oracle propensities; operational propensity estimation can be biased or unstable.
4. No causal inference about the effects of deploying AI is made.
5. Ten seeds provide an initial engineering check, not definitive statistical evidence.
6. No actual FAIR-AI assurance model has yet been evaluated; this is a comparator benchmark.
7. We have not conducted a systematic novelty review or calculated real financial benefits.

## Reproduction
Run `python experiment.py` with Python 3, numpy and pandas. The script overwrites `replicate_results.csv`, `summary.csv` and `scenario_examples.csv`. Random seeds and all model parameters are in the script. No Citi data, personal data or confidential information is used.
