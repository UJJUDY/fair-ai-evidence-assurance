"""Synthetic selective-labels experiment. Requires numpy and pandas. Deterministic seeds."""
import numpy as np, pandas as pd
from pathlib import Path
OUT=Path(__file__).resolve().parent
N=100_000; SEEDS=range(20261015,20261025)
rows=[]; examples=[]
for drift in (0.0,0.055,0.11):
 for seed in SEEDS:
  rng=np.random.default_rng(seed)
  # Risk groups are observable; hidden true error is not visible unless audited/reviewed.
  group=rng.choice(4,size=N,p=[.4,.3,.2,.1]); baseline=np.array([.015,.04,.095,.18]);
  true_p=np.clip(baseline[group]+drift*np.array([.2,.5,.8,1.])[group],0,.95)
  failure=(rng.random(N)<true_p).astype(int)
  # System preferentially reviews low-risk cases; review probability decreases as deployment scales.
  review_p=(np.array([.80,.48,.20,.055]) if drift==0 else np.array([.85,.25,.06,.01]) if drift==0.055 else np.array([.90,.12,.025,.003]))[group]
  reviewed=rng.random(N)<review_p
  observed=np.where(reviewed,failure,np.nan)
  # Independent probability audit: 2000 randomly selected across ALL decisions.
  audit_idx=rng.choice(N,size=2000,replace=False)
  # Stratified audit with same budget: allocate 500 to each known risk group.
  strata=[]
  for g in range(4):
   idx=np.flatnonzero(group==g)
   strata.append(rng.choice(idx,size=500,replace=False))
  strata=np.concatenate(strata)
  true_rate=failure.mean()
  naive=np.nanmean(observed)
  random_audit=failure[audit_idx].mean()
  # IPW estimator: known true review inclusion probabilities (unrealistically favorable to IPW).
  ipw=np.mean(np.where(reviewed,failure/review_p,0))
  # Stratified independent audit weighted by full population group shares.
  stratified=sum(np.mean(group==g)*failure[strata[group[strata]==g]].mean() for g in range(4))
  # apparent quality is 1 - error; failure risk may increase while reviewed subset stays deceptively low
  for method,estimate in [('Reviewed-only dashboard',naive),('Random independent audit',random_audit),('Inverse-propensity weighting',ipw),('Stratified independent audit',stratified)]:
   rows.append(dict(seed=seed,drift=drift,method=method,truth=true_rate,estimate=estimate,absolute_error=abs(estimate-true_rate),signed_error=estimate-true_rate,review_rate=reviewed.mean(),audit_budget=2000 if 'audit' in method.lower() else 0))
  if seed==20261015:
   examples.append(dict(drift=drift,true_error=true_rate,reviewed_error=naive,review_fraction=reviewed.mean(),n=N))
df=pd.DataFrame(rows); df.to_csv(OUT/'replicate_results.csv',index=False)
sumry=df.groupby(['drift','method'],as_index=False).agg(mean_true_error=('truth','mean'),mean_estimated_error=('estimate','mean'),mean_absolute_error=('absolute_error','mean'),mean_signed_error=('signed_error','mean'),replicates=('seed','count'))
sumry.to_csv(OUT/'summary.csv',index=False)
pd.DataFrame(examples).to_csv(OUT/'scenario_examples.csv',index=False)
print(sumry.to_string(index=False,float_format=lambda x:f'{x:.4f}'))
