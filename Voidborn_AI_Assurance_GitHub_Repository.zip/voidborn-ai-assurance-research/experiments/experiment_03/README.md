# Voidborn Tech — AI Measurement Blind Spot

Run: `python experiment.py` (requires numpy, pandas).

- `RESEARCH_REPORT.md` — design, numerical results, interpretation, limitations.
- `experiment.py` — fully reproducible synthetic simulator.
- `summary.csv` — means by scenario and method.
- `replicate_results.csv` — 120 individual estimator runs (3 scenarios × 10 seeds × 4 methods).
- `scenario_examples.csv` — example scenario-level records.

This is independent hypothetical research, not a Citi collaboration, a Citi audit or a validated FAIR-AI system.
