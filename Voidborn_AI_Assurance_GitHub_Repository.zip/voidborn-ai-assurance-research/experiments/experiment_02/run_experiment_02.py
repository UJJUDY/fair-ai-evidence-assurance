"""Experiment 02: independently generated faults, partial telemetry and cross-agent lineage.
Synthetic only. Standard library. Run: python run_experiment_02.py
"""
import csv, random, json, hashlib
from pathlib import Path
from collections import Counter
R=random.Random(20261016)
OUT=Path(__file__).parent/'experiment_02';OUT.mkdir(exist_ok=True)
N=600
rows=[];events=[]
# Hidden simulator truth is determined by underlying facts; detector only observes noisy telemetry.
for i in range(N):
 cid=f'EXP2-{i+1:04d}'
 risk=R.choice(['low','medium','high']); source_complete=R.random()>.18
 conflicting=R.random()<.12; unauthorized=R.random()<.09
 meaningful_review=R.random()>.17; provenance_broken=R.random()<.16
 # Workflow fault arises from combined agents; each component may still report a local pass.
 harmful=(not source_complete or conflicting or unauthorized or not meaningful_review or provenance_broken)
 local_pass_a=not unauthorized;local_pass_b=not conflicting;local_pass_c=True
 # Independent telemetry: 12% missing, plus noisy/misleading status reports.
 missing=R.random()<.12
 def noisy(x,p=.08):return (not x) if R.random()<p else x
 log_permission=None if missing else noisy(local_pass_a)
 log_source=None if missing else noisy(source_complete)
 log_review=None if missing else noisy(meaningful_review)
 log_consistency=None if missing else noisy(local_pass_b)
 # Provenance validation is available for most but not all records, with false alarms.
 lineage_signal=None if missing else noisy(not provenance_broken,.11)
 # Baseline: alerts only on reported failures, ignores missing telemetry and lineage.
 base=any(x is False for x in (log_permission,log_source,log_review,log_consistency))
 # Candidate: provenance, unknown telemetry, and cross-step checks; independent holdout fixture.
 candidate=base or lineage_signal is False or missing
 rows.append(dict(case_id=cid,underlying_issue=int(harmful),baseline_alert=int(base),candidate_alert=int(candidate),telemetry_missing=int(missing),source_complete=int(source_complete),contradictory_inputs=int(conflicting),unauthorized_action=int(unauthorized),meaningful_review=int(meaningful_review),provenance_broken=int(provenance_broken),local_agent_checks_pass=int(local_pass_a and local_pass_b and local_pass_c),baseline_missed_issue=int(harmful and not base),candidate_missed_issue=int(harmful and not candidate)))
 for agent,status in [('intake',local_pass_a),('risk_assessment',local_pass_b),('recommendation',local_pass_c)]:
  events.append(dict(case_id=cid,agent=agent,local_check_pass=int(status),telemetry_present=int(not missing),parent_case_id=cid,synthetic=True))
def write(name,data):
 with (OUT/name).open('w',newline='') as f:
  w=csv.DictWriter(f,fieldnames=list(data[0]));w.writeheader();w.writerows(data)
write('synthetic_cases.csv',rows);write('agent_events.csv',events)
def metrics(pred):
 c=Counter(('TP' if r['underlying_issue'] and r[pred] else 'FN' if r['underlying_issue'] else 'FP' if r[pred] else 'TN') for r in rows)
 return dict(TP=c['TP'],FP=c['FP'],TN=c['TN'],FN=c['FN'],recall=round(c['TP']/(c['TP']+c['FN']),4),precision=round(c['TP']/(c['TP']+c['FP']),4),false_positive_rate=round(c['FP']/(c['FP']+c['TN']),4))
results={'baseline':metrics('baseline_alert'),'candidate':metrics('candidate_alert')}
results['local_pass_with_underlying_issue']=sum(r['local_agent_checks_pass'] and r['underlying_issue'] for r in rows)
results['cases']=N;results['seed']=20261016
(OUT/'metrics.json').write_text(json.dumps(results,indent=2))
(OUT/'report.md').write_text(f'''# Experiment 02 — Cross-agent assurance under incomplete evidence

## Research hypothesis
An assurance rule that includes provenance and treats missing telemetry as an exception can detect more injected workflow faults than a rule that relies on local agent status signals alone, but may increase false positives.

## Experimental setup
- {N} synthetic cases, three simulated agents per case, deterministic seed 20261016.
- Independent underlying fault variables include missing source material, contradictory inputs, unauthorized action, weak human review, and broken provenance.
- Telemetry may be missing (12% probability) or inaccurate (8% status inversion; 11% for provenance).
- Baseline uses only four local status signals. Candidate adds lineage and missing-telemetry escalation.
- Neither detector sees the underlying ground-truth fault fields. Both are evaluated on the same synthetic cases.

## Results
```json
{json.dumps(results,indent=2)}
```

## Important interpretation
These are *simulator outcomes*, not validation against real banking workflows. The candidate detector was deliberately designed for the synthetic failure distribution; this is not an independent real-world benchmark. More alerts are not necessarily better: investigate precision, false-positive rate, alert burden and costs. Local checks passing does not prove global correctness.

## Limitations and next steps
No LLM or actual AI agents, no Citi data, no customer data, no causal demonstration of improved compliance, no independently adjudicated production labels. Future studies should add unseen fault types, calibrated severity, reviewer adjudication, evidence graph integrity, operational costs, and sensitivity to distribution shifts.
''')
(OUT/'manifest.json').write_text(json.dumps({'seed':20261016,'synthetic':True,'files':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in OUT.glob('*.csv')}},indent=2))
print(json.dumps(results,indent=2))
