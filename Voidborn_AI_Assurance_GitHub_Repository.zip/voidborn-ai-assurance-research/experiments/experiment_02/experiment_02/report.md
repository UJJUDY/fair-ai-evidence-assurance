# Experiment 02 — Cross-agent assurance under incomplete evidence

## Research hypothesis
An assurance rule that includes provenance and treats missing telemetry as an exception can detect more injected workflow faults than a rule that relies on local agent status signals alone, but may increase false positives.

## Experimental setup
- 600 synthetic cases, three simulated agents per case, deterministic seed 20261016.
- Independent underlying fault variables include missing source material, contradictory inputs, unauthorized action, weak human review, and broken provenance.
- Telemetry may be missing (12% probability) or inaccurate (8% status inversion; 11% for provenance).
- Baseline uses only four local status signals. Candidate adds lineage and missing-telemetry escalation.
- Neither detector sees the underlying ground-truth fault fields. Both are evaluated on the same synthetic cases.

## Results
```json
{
  "baseline": {
    "TP": 260,
    "FP": 66,
    "TN": 193,
    "FN": 81,
    "recall": 0.7625,
    "precision": 0.7975,
    "false_positive_rate": 0.2548
  },
  "candidate": {
    "TP": 331,
    "FP": 117,
    "TN": 142,
    "FN": 10,
    "recall": 0.9707,
    "precision": 0.7388,
    "false_positive_rate": 0.4517
  },
  "local_pass_with_underlying_issue": 218,
  "cases": 600,
  "seed": 20261016
}
```

## Important interpretation
These are *simulator outcomes*, not validation against real banking workflows. The candidate detector was deliberately designed for the synthetic failure distribution; this is not an independent real-world benchmark. More alerts are not necessarily better: investigate precision, false-positive rate, alert burden and costs. Local checks passing does not prove global correctness.

## Limitations and next steps
No LLM or actual AI agents, no Citi data, no customer data, no causal demonstration of improved compliance, no independently adjudicated production labels. Future studies should add unseen fault types, calibrated severity, reviewer adjudication, evidence graph integrity, operational costs, and sensitivity to distribution shifts.
