# Voidborn Tech | Experiment 06 — The Cost of Uncertainty
**Independent synthetic research; no Citi internal data or claims about Citi's systems.**

## Research question
When labels are selectively observed, can independent sampling and uncertainty-aware deployment rules reduce unsafe decisions, and at what opportunity cost?

## Design
- Two pre-specified regimes, 100 seeds per regime, 20,000 synthetic cases per run.
- Latent and observed risk factors influence errors and review selection. 80% of selected reviews become timely observed labels.
- An independent random audit of 250 cases provides labels across the population, including cases normally not reviewed. This is a strong assumption; in actual credit or onboarding settings some counterfactual outcomes cannot be observed even after audit.
- Compare observed-only decision, independent-audit point estimate, and conservative one-sided Hoeffding upper bound at nominal 95% per decision.
- Approval requires estimated error <= 12% and modeled unit economics positive. Hypothetical benefit 15 units, error loss 100 units, independent audit cost 0.2 units per case. These numbers are illustrative, not bank estimates.
- No novel statistical estimator is claimed. No formal validation of FAIR-AI is claimed.

## Findings
| Scenario | Method | Approval rate | Unsafe approvals / 100 | Missed opportunities / 100 | Mean modeled payoff per case |
|---|---|---:|---:|---:|---:|
| Baseline | Observed only | 100% | 0 | 0 | 8.638 |
| Baseline | Independent audit point | 100% | 0 | 0 | 8.438 |
| Baseline | Conservative bound | 4% | 0 | 96 | 0.142 |
| Deteriorated | Observed only | 100% | 100 | 0 | 1.190 |
| Deteriorated | Independent audit point | 21% | 21 | 0 | 0.063 |
| Deteriorated | Conservative bound | 0% | 0 | 0 | -0.200 |

The risk limit is separate from expected payoff: a policy can yield positive simulated profit and still breach its risk appetite. All payoffs are hypothetical and omit many real costs.

## Interpretation
The result is a negative finding for a simplistic 'more conservative is better' thesis. A confidence-bound decision rule substantially reduces unsafe approvals but can reject almost all acceptable deployments when the audit budget is small. The central research question becomes *how to allocate scarce evidence-gathering resources and choose calibrated decision rules under non-observability*. Independent sampling is an established method, not a Voidborn innovation.

## Limitations
1. Synthetic ground truth and correctly ascertained audit outcomes are available to the experimenter. This is not always possible in banking.
2. Risk limit, audit budget, loss coefficients and data-generating processes are assumed, not estimated.
3. Results do not establish nominal coverage under all dependencies or distribution shifts.
4. One-sided Hoeffding bounds are conservative and do not optimize the economic decision. Stronger benchmarks include empirical Bernstein, Bayesian decision rules, sequential testing, and partial-identification bounds.
5. The same 100 seeds are reused within a regime but not across regimes. Simulation is not a Citi case study of actual outcomes.
6. The reported 'unsafe approvals' reflect the chosen risk threshold; they are not measured customer harm or regulatory breaches.

## Next falsification tests
- Remove the assumption that audit reveals counterfactual outcomes; derive partial-identification bounds.
- Test sequential sampling and adaptive audit budgets against fixed-size audits with matched cost.
- Vary loss asymmetry, jurisdiction-specific risk appetite, label delay, correlated errors and distribution shift.
- Pre-register evaluation metrics, add uncertainty intervals for differences, and compare to established robust decision frameworks.

## Reproduction
`python experiment.py` with numpy and pandas. Outputs: `replicate_results.csv`, `summary.csv`. All randomness is seeded.
