# Experiment 06 — The Cost of Uncertainty
Run `python experiment.py` (requires numpy and pandas). Read `RESEARCH_REPORT.md` before interpreting the synthetic metrics. The dataset and methods are illustrative and not derived from Citi systems.
