"""Experiment 06: uncertainty-aware approval with selective labels and audit budget.
Reproduce: python experiment.py. Python/numpy/pandas only.
"""
from pathlib import Path
import numpy as np
import pandas as pd
ROOT=Path(__file__).resolve().parent
SEEDS=range(100); N=10000; AUDIT_N=250
RISK_LIMIT=.12; BENEFIT=15.; LOSS_PER_ERROR=100.; AUDIT_COST=.20
# economic assumptions in hypothetical units per case, NOT dollars or Citi estimates.

def evaluate(seed, regime):
    rng=np.random.default_rng(9000+seed+10000*regime)
    x=rng.normal(size=N); latent=rng.normal(size=N)
    # regime 0 is low risk; regime 1 is higher risk and stronger selection
    true_p=1/(1+np.exp(-(-3.1+.65*x+.75*latent+regime*.95)))
    errors=(rng.random(N)<true_p).astype(int)
    # Observed labels are selected, and some outcomes are delayed.
    selection=1/(1+np.exp(-(.2-.2*x-.2*latent-regime*(1.0*x+1.3*latent))))
    reviewed=rng.random(N)<selection
    timely=reviewed & (rng.random(N)<.8)
    naive=errors[timely].mean()
    # independent audit sampled from whole population, including cases normally unreviewed;
    # assumes independent audit can ascertain outcomes (not possible for every real-world outcome).
    audit=rng.choice(N,AUDIT_N,replace=False)
    audit_rate=errors[audit].mean()
    # Hoeffding one-sided bound (conservative; 95% per decision)
    radius=np.sqrt(np.log(1/.05)/(2*AUDIT_N))
    upper=min(1.,audit_rate+radius)
    # Decision policy: deploy if risk acceptable AND expected unit economics positive.
    def approve(rate): return bool(rate<=RISK_LIMIT and BENEFIT-LOSS_PER_ERROR*rate>0)
    oracle=approve(errors.mean()); naive_dec=approve(naive)
    audited_point=approve(audit_rate); robust=approve(upper)
    # count avoidable risk-limit breaches; all policies are assessed against true rate
    row=dict(seed=seed,regime=['baseline','deteriorated'][regime],true_risk=errors.mean(),
      observed_risk=naive,audit_risk=audit_rate,upper95=upper,review_fraction=timely.mean(),
      oracle=oracle,naive=naive_dec,audit_point=audited_point,robust=robust)
    for name in ('naive','audit_point','robust'):
        d=row[name]
        row[name+'_unsafe_approval']=int(d and not oracle)
        row[name+'_missed_opportunity']=int((not d) and oracle)
        # realized unit payoff if approved; abstention payoff=0; audit cost charged to audit policies
        row[name+'_payoff']=(BENEFIT-LOSS_PER_ERROR*row['true_risk']) if d else 0.
        if name!='naive': row[name+'_payoff']-=AUDIT_COST
    return row

rows=[evaluate(seed,regime) for regime in (0,1) for seed in SEEDS]
df=pd.DataFrame(rows); df.to_csv(ROOT/'replicate_results.csv',index=False)
summary=[]
for regime,g in df.groupby('regime'):
    for method in ['naive','audit_point','robust']:
        summary.append(dict(regime=regime,method=method,runs=len(g),true_risk=g.true_risk.mean(),
          observed_risk=g.observed_risk.mean(),audit_risk=g.audit_risk.mean(),
          approval_rate=g[method].mean(),unsafe_approvals=int(g[method+'_unsafe_approval'].sum()),
          missed_opportunities=int(g[method+'_missed_opportunity'].sum()),
          mean_payoff=g[method+'_payoff'].mean()))
pd.DataFrame(summary).to_csv(ROOT/'summary.csv',index=False)
print(pd.DataFrame(summary).to_string(index=False))
