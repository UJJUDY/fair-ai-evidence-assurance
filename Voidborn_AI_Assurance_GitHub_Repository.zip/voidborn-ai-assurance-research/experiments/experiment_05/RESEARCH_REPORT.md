# Voidborn Tech | Experiment 05 — The Unobservable Risk Problem
Date: 15 October 2026
Status: Synthetic simulation, not an assessment of Citi systems.

## Question
When an AI-assisted banking decision determines whether a customer is onboarded, how can a bank estimate the adverse-outcome risk *if all applicants were onboarded*, given that outcomes for rejected applicants are not observed?

## Design
40 seeds per regime, 20,000 cases per seed (1.6 million synthetic case instances in total). Two potential outcomes per case are generated internally: adverse outcome if onboarded (Y1) and if rejected (Y0). The estimand is the population mean of Y1, observable to the simulator as an oracle but not to an actual bank. Observed features x and hidden factor u both affect acceptance and Y1. An 85% outcome-maturity probability further removes labels among accepted cases.

Two regimes: deterministic selection based on x and u, and a hypothetical 10% exploration policy that randomly assigns decisions with equal probability for exploration cases. The latter is **not a recommendation to randomize real onboarding decisions**; legal, safety, fairness, customer protection, and AML obligations may prohibit this.

Comparators: reviewed-only mean, x-decile standardization (cannot adjust hidden u), and known-propensity inverse-probability weighting (IPW) in the exploration regime. The IPW estimator assumes correct recorded propensities and independent 85% outcome maturity, both guaranteed by the simulation but not by real data. We also calculate worst-case bounds on the target risk with no assumptions about missing Y1 outcomes.

## Results
| Regime | Estimator | Mean estimate | Mean absolute error | RMSE |
|---|---|---:|---:|---:|
| Deterministic | Observed-only | 6.659% | 10.728 pp | 10.731 pp |
| Deterministic | x-standardized | 7.687% | 9.701 pp | 9.704 pp |
| Exploration | Observed-only | 7.606% | 9.781 pp | 9.784 pp |
| Exploration | x-standardized | 9.196% | 8.191 pp | 8.197 pp |
| Exploration | Known-propensity IPW | 17.447% | 1.055 pp | 1.332 pp |

True mean population risk: 17.387%. Mean worst-case bounds: deterministic 3.20% to 55.18%, exploration 3.61% to 56.12%. Bounds are wide, demonstrating partial identification absent assumptions. Randomized IPW is already an established statistical method; the experiment does **not** establish a novel FAIR-AI estimator.

## Interpretation
A policy can make its own risk measurement misleading by restricting which cases have outcomes. Hidden selection variables prevent observed-feature standardization from fully repairing bias. Positivity and known propensities enable an existing IPW estimator to recover the population risk in this constructed setting. There is no evidence of superior performance by a proprietary FAIR-AI method.

## Limitations and next questions
- Outcome Y1 for every rejected customer is *counterfactual*, and the simulator knows it only because it generated both potential outcomes.
- Simulated selection is deliberately biased; findings do not measure the prevalence of this problem in any bank.
- The target (risk if everyone were onboarded) may be inappropriate for certain business decisions and is not a fairness or regulatory compliance measure by itself.
- The experiment assumes stationary outcome generation, no interference, known randomization propensities, and missing-at-random maturation; these are strong assumptions.
- Real-world random onboarding could be impermissible; alternatives include shadow evaluation with qualified human review, natural experiments, bounds and sensitivity analysis, subject to legal/ethical review.
- Need to model delayed outcomes dependent on risk, uncertainty intervals, shifts in policy, differential customer harms, and economic impact. Evaluate methods against published research before asserting novelty.

## Reproduce
`python experiment.py` with numpy and pandas installed. Output files: `replicate_results.csv`, `summary.csv`.
