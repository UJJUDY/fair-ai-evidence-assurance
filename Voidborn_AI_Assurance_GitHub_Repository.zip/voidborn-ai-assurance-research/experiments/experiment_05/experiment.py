"""Synthetic potential-outcomes experiment. Requires numpy and pandas. Seeded."""
import numpy as np, pandas as pd
from pathlib import Path
ROOT=Path(__file__).resolve().parent
N=20000; REPS=40

def sigmoid(z): return 1/(1+np.exp(-np.clip(z,-30,30)))

def run(seed, regime):
    rng=np.random.default_rng(20261015+seed)
    x=rng.normal(size=N); u=rng.normal(size=N)  # u is NOT observed by analyst
    # Binary adverse outcome if onboarded (Y1), and if not onboarded (Y0).
    # Outcomes are potential outcomes, not both observable in real banking.
    p1=sigmoid(-2.0+.85*x+.95*u)
    p0=sigmoid(-2.8+.30*x+.40*u)
    y1=(rng.random(N)<p1).astype(float)
    y0=(rng.random(N)<p0).astype(float)
    # Policy systematically rejects high-risk clients, based on x and hidden u.
    policy_p=sigmoid(.3-1.1*x-1.5*u)
    if regime=='deterministic':
        accept=(policy_p>.5)
        known_p=None
    else:
        # 10% randomized decision exploration, ethically only a simulation.
        # In a real bank random onboarding may be unacceptable / prohibited.
        known_p=.9*(policy_p>.5).astype(float)+.1*.5
        accept=rng.random(N)<known_p
    # Delayed outcomes: even accepted cases may lack matured labels
    mature=rng.random(N)<.85
    observed=accept&mature
    truth=y1.mean()  # oracle estimand: adverse rate if EVERYONE were onboarded
    naive=y1[observed].mean()
    # x-stratified observational standardization cannot remove latent-u confounding
    bins=np.digitize(x,np.quantile(x,np.linspace(0,1,11)[1:-1]))
    standardized=sum((bins==k).mean() * (y1[observed&(bins==k)].mean() if np.any(observed&(bins==k)) else np.nan) for k in range(10))
    # Nonparametric worst-case Manski bounds: unobserved Y1 could be 0 or 1
    lower=np.sum(y1[observed])/N
    upper=(np.sum(y1[observed])+N-observed.sum())/N
    ipw=np.nan
    if known_p is not None:
        # Randomized propensities known; maturity is MCAR by construction.
        inclusion=known_p*.85
        ipw=np.mean(np.where(observed,y1/inclusion,0.0))
    return dict(seed=seed,regime=regime,oracle_risk=truth,naive_reviewed=naive,
        x_standardized=standardized,ipw_exploration=ipw,bound_lower=lower,
        bound_upper=upper,observation_rate=observed.mean(),
        bound_width=upper-lower)

rows=[run(s,r) for r in ['deterministic','exploration'] for s in range(REPS)]
df=pd.DataFrame(rows);df.to_csv(ROOT/'replicate_results.csv',index=False)
summary=[]
for regime,g in df.groupby('regime'):
    for method in ['naive_reviewed','x_standardized','ipw_exploration']:
        valid=g[method].notna()
        if not valid.any():continue
        err=g.loc[valid,method]-g.loc[valid,'oracle_risk']
        summary.append(dict(regime=regime,method=method,n_runs=int(valid.sum()),
           mean_true_risk=g.loc[valid,'oracle_risk'].mean(),
           mean_estimate=g.loc[valid,method].mean(),bias=err.mean(),
           mae=err.abs().mean(),rmse=np.sqrt((err**2).mean()),
           mean_observed_fraction=g.loc[valid,'observation_rate'].mean()))
pd.DataFrame(summary).to_csv(ROOT/'summary.csv',index=False)
print(pd.DataFrame(summary).to_string(index=False,float_format=lambda x:f'{x:.5f}'))
print('\nBounds (average):')
print(df.groupby('regime')[['bound_lower','bound_upper','bound_width','observation_rate']].mean().to_string(float_format=lambda x:f'{x:.4f}'))
