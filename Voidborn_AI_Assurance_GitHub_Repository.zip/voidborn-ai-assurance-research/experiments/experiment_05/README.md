# Experiment 05 research package
Run `python experiment.py` (requires numpy and pandas). See `RESEARCH_REPORT.md` for assumptions, results and limitations. All data are synthetic; no Citi data are used. The experiment tests established statistical methods and does not validate FAIR-AI as a proprietary solution.
