# Voidborn Tech | AI Assurance Research

**Independent synthetic research portfolio — Citi public-information case study**

This repository contains six reproducible experiments exploring evidence quality, cross-agent controls, selective observation, unobservable outcomes, and uncertainty-aware AI deployment decisions in illustrative banking workflows.

**No Citi operational data, code, endorsement, or internal system access is involved.** The experiments use synthetic scenarios and should not be interpreted as evidence of weaknesses in Citi's controls. FAIR-AI is a proposed research approach, **not a certified compliance solution**.

## Research question

How can a financial institution distinguish AI systems that are demonstrably low-risk from systems that only appear low-risk because important outcomes and assurance evidence are missing?

## Experiments

| Folder | Topic | Main limitation |
|---|---|---|
| `experiment_01` | Five basic assurance controls | Rules and injected issues share assumptions |
| `experiment_02` | Cross-agent evidence continuity | Synthetic scenarios informed detector design |
| `experiment_03` | Selective observation and monitoring bias | Existing audit methods already address much of the issue |
| `experiment_04` | Measurement paradox under selection | Proposed trace method did not beat conventional stratification |
| `experiment_05` | Unobservable outcomes and selection bias | Randomized comparator requires different assumptions |
| `experiment_06` | Risk limits and cost of uncertainty | Conservative bounds may reject acceptable deployments |

## Quick start

Requires Python 3.10+.

```bash
python -m pip install -r requirements.txt
python experiments/experiment_01/run_experiment.py
python experiments/experiment_02/run_experiment_02.py
python experiments/experiment_03/experiment.py
python experiments/experiment_04/experiment.py
python experiments/experiment_05/experiment.py
python experiments/experiment_06/experiment.py
```

Run commands from the repository root. Some scripts write results alongside their source files; rerunning may overwrite bundled output files. To preserve original outputs, work on a separate branch or copy.

Read each experiment's `README.md` and report before interpreting metrics. CSV files in this repository are **synthetic**, and experiments are not independently peer reviewed or validated against real bank systems.

## Reproducibility and interpretation

Scripts and the corresponding archived outputs from the original experiments are included. This repository preserves the original experiment code rather than rewriting the underlying simulations. Compare fresh outputs with the archived summaries and review differences due to environment or stochastic design.

A positive synthetic result does not establish effectiveness in production. In particular, Experiment 04 did **not** show superiority of the proposed trace-informed estimator over conventional stratified auditing.

## Research attribution

Voidborn Tech — independent applied AI governance research. Citi is used only as public-information context and is not affiliated with or endorsing this project.

## License

No license has been granted for reuse. Contact the repository owner for permissions. A separate open-source license can be added if desired.
